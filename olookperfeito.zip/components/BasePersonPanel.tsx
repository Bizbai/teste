import React, { useRef } from 'react';
import { UploadIcon, XMarkIcon } from './Icons';

interface BasePersonPanelProps {
  image: string | null;
  onImageUpload: (file: File) => void;
  onRemove: () => void;
}

const BasePersonPanel: React.FC<BasePersonPanelProps> = ({ image, onImageUpload, onRemove }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onImageUpload(file);
    }
  };

  const handleClick = () => {
    if (!image) {
      fileInputRef.current?.click();
    }
  };

  return (
    <div className="flex flex-col h-full">
      <h2 className="text-lg font-semibold text-gray-800 mb-4">Base Person</h2>
      <div 
        className={`relative flex-1 rounded-2xl border-2 transition-all duration-300 overflow-hidden group
          ${image ? 'border-gray-200 bg-white shadow-sm' : 'border-dashed border-gray-300 bg-gray-50 hover:bg-gray-100 cursor-pointer'}
        `}
        onClick={handleClick}
      >
        <input 
          type="file" 
          ref={fileInputRef} 
          className="hidden" 
          accept="image/*" 
          onChange={handleFileChange}
        />

        {image ? (
          <div className="relative w-full h-full">
            <img src={image} alt="Base person" className="w-full h-full object-cover" />
            <button 
              onClick={(e) => { e.stopPropagation(); onRemove(); }}
              className="absolute top-2 right-2 bg-white/80 backdrop-blur rounded-full p-1.5 shadow-sm hover:bg-white text-gray-700 transition-colors"
            >
              <XMarkIcon className="w-5 h-5" />
            </button>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-gray-400">
            <UploadIcon className="w-12 h-12 mb-2" />
            <span className="text-sm font-medium">Upload photo</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default BasePersonPanel;
