import React from 'react';
import { CameraIcon } from './Icons';

const Header: React.FC = () => {
  return (
    <header className="bg-white h-16 border-b border-gray-100 flex items-center justify-between px-6 sticky top-0 z-10 shadow-sm">
      <div className="flex-1 flex justify-start">
        <h1 className="text-xl font-bold tracking-tight text-gray-900">olookperfeito</h1>
      </div>
      <div className="flex-1"></div>
      <div className="flex-1 flex justify-end">
        <button className="p-2 rounded-full hover:bg-gray-100 transition-colors text-gray-600">
          <CameraIcon className="w-6 h-6" />
        </button>
      </div>
    </header>
  );
};

export default Header;
