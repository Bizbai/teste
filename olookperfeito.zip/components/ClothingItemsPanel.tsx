import React, { useRef } from 'react';
import { PlusIcon, XMarkIcon } from './Icons';
import { ClothingItem } from '../types';

interface ClothingItemsPanelProps {
  items: ClothingItem[];
  onAddItems: (files: FileList) => void;
  onRemoveItem: (id: string) => void;
}

const ClothingItemsPanel: React.FC<ClothingItemsPanelProps> = ({ items, onAddItems, onRemoveItem }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      onAddItems(e.target.files);
    }
    // Reset input so same file can be selected again if needed
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold text-gray-800">Clothing Items</h2>
        <button 
          onClick={() => fileInputRef.current?.click()}
          className="text-sm text-blue-600 font-medium hover:text-blue-700 flex items-center gap-1"
        >
          <PlusIcon className="w-4 h-4" /> Add Item
        </button>
      </div>

      <input 
        type="file" 
        ref={fileInputRef} 
        className="hidden" 
        multiple 
        accept="image/*" 
        onChange={handleFileChange}
      />

      <div className="flex-1 bg-gray-50 rounded-2xl p-4 overflow-y-auto border border-gray-100 shadow-inner">
        {items.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-gray-400">
            <p className="text-sm">No items added yet</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {items.map((item) => (
              <div key={item.id} className="relative group bg-white rounded-xl overflow-hidden shadow-sm border border-gray-100 aspect-[3/4]">
                <img src={item.data} alt="Clothing item" className="w-full h-full object-cover" />
                <button 
                  onClick={() => onRemoveItem(item.id)}
                  className="absolute top-1.5 right-1.5 bg-white/90 rounded-full p-1 shadow-sm opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-50 text-red-500"
                >
                  <XMarkIcon className="w-4 h-4" />
                </button>
              </div>
            ))}
            {/* Add placeholder card */}
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center justify-center bg-white rounded-xl border-2 border-dashed border-gray-200 aspect-[3/4] hover:bg-gray-50 hover:border-gray-300 transition-colors text-gray-300"
            >
              <PlusIcon className="w-8 h-8" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default ClothingItemsPanel;
