import React, { useState } from 'react';
import { XMarkIcon, SparklesIcon } from './Icons';
import { editGeneratedImage } from '../services/geminiService';

interface ImageEditorModalProps {
  isOpen: boolean;
  onClose: () => void;
  image: string;
  onImageUpdate: (newImage: string) => void;
}

const ImageEditorModal: React.FC<ImageEditorModalProps> = ({ isOpen, onClose, image, onImageUpdate }) => {
  const [prompt, setPrompt] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [currentImage, setCurrentImage] = useState(image);

  if (!isOpen) return null;

  const handleEdit = async () => {
    if (!prompt.trim() || isProcessing) return;
    setIsProcessing(true);
    try {
      const newImg = await editGeneratedImage(currentImage, prompt);
      setCurrentImage(newImg);
      onImageUpdate(newImg);
      setPrompt('');
    } catch (error) {
      console.error("Failed to edit image");
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="bg-white rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 border-b border-gray-100 flex justify-between items-center">
          <h3 className="font-semibold text-lg text-gray-800">Edit Image (Nano Banana)</h3>
          <button onClick={onClose} className="p-1 hover:bg-gray-100 rounded-full text-gray-500">
            <XMarkIcon className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-auto p-6 bg-gray-50 flex items-center justify-center">
          <div className="relative rounded-lg overflow-hidden shadow-md max-h-full">
            <img src={currentImage} alt="To Edit" className="max-w-full max-h-[60vh] object-contain" />
            {isProcessing && (
               <div className="absolute inset-0 bg-white/50 backdrop-blur-sm flex items-center justify-center">
                 <div className="w-10 h-10 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
               </div>
            )}
          </div>
        </div>

        {/* Footer / Input */}
        <div className="p-4 bg-white border-t border-gray-100">
          <p className="text-xs text-gray-500 mb-2 font-medium">Describe your edit (e.g., "Add a retro filter", "Change background to beach")</p>
          <div className="flex gap-2">
            <input
              type="text"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Enter edit instruction..."
              className="flex-1 border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
              onKeyDown={(e) => e.key === 'Enter' && handleEdit()}
            />
            <button
              onClick={handleEdit}
              disabled={isProcessing || !prompt.trim()}
              className="bg-black text-white px-5 py-2.5 rounded-xl text-sm font-medium hover:bg-gray-800 disabled:opacity-50 transition-colors flex items-center gap-2"
            >
              <SparklesIcon className="w-4 h-4" />
              Apply
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ImageEditorModal;
