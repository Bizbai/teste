import React from 'react';
import { SparklesIcon } from './Icons';
import { GenerationState } from '../types';

interface GeneratedLookPanelProps {
  resultImage: string | null;
  generationState: GenerationState;
  onGenerate: () => void;
  onEdit: () => void;
  canGenerate: boolean;
}

const GeneratedLookPanel: React.FC<GeneratedLookPanelProps> = ({ 
  resultImage, 
  generationState, 
  onGenerate, 
  onEdit,
  canGenerate 
}) => {
  return (
    <div className="flex flex-col h-full relative">
      <h2 className="text-lg font-semibold text-gray-800 mb-4">Generated Look</h2>
      
      {/* Image Container */}
      <div className="flex-1 bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden relative group">
        {generationState.status === 'processing' ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-white z-10">
            <div className="w-12 h-12 border-4 border-blue-100 border-t-blue-600 rounded-full animate-spin mb-4"></div>
            <p className="text-gray-500 font-medium animate-pulse">Creating your look...</p>
          </div>
        ) : null}

        {resultImage ? (
          <>
            <img src={resultImage} alt="Generated Look" className="w-full h-full object-contain bg-gray-50" />
            <div className="absolute top-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
               <button 
                 onClick={onEdit}
                 className="bg-white/90 backdrop-blur border border-gray-200 shadow-sm px-3 py-1.5 rounded-lg text-sm font-medium text-gray-700 hover:bg-white"
               >
                 Edit with AI
               </button>
               <a 
                 href={resultImage} 
                 download="olookperfeito-tryon.png"
                 className="bg-black/80 backdrop-blur shadow-sm px-3 py-1.5 rounded-lg text-sm font-medium text-white hover:bg-black"
               >
                 Download
               </a>
            </div>
          </>
        ) : (
          <div className="h-full flex flex-col items-center justify-center text-gray-300">
            <SparklesIcon className="w-16 h-16 mb-2 opacity-50" />
            <p className="text-sm font-medium">Result will appear here</p>
          </div>
        )}
      </div>

      {/* Action Area */}
      <div className="mt-4 flex justify-end">
        <button
          onClick={onGenerate}
          disabled={!canGenerate || generationState.status === 'processing'}
          className={`
            flex items-center gap-2 px-6 py-3 rounded-xl font-semibold text-white shadow-lg shadow-blue-500/20 transition-all
            ${!canGenerate || generationState.status === 'processing' 
              ? 'bg-gray-300 cursor-not-allowed shadow-none' 
              : 'bg-blue-600 hover:bg-blue-700 hover:shadow-blue-500/30 active:scale-95'}
          `}
        >
          {generationState.status === 'processing' ? 'Processing...' : (
            <>
              <SparklesIcon className="w-5 h-5" />
              Generate Look
            </>
          )}
        </button>
      </div>

      {generationState.status === 'error' && (
        <div className="absolute bottom-20 left-0 right-0 p-3 mx-4 bg-red-50 text-red-600 text-sm rounded-lg border border-red-100">
          {generationState.error || "Something went wrong. Please try again."}
        </div>
      )}
    </div>
  );
};

export default GeneratedLookPanel;
