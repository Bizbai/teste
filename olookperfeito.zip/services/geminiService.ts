import { GoogleGenAI, Type } from "@google/genai";
import { ChatMessage } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const TRY_ON_SYSTEM_PROMPT = `
You are the AI engine behind olookperfeito, a virtual try-on application.
The user will upload:
1. A full-body photo of themselves (the first image).
2. One or more photos of clothing items or accessories.

Your task is to generate a single realistic image of the user wearing all the selected items.

Rules:
- Preserve the user’s identity, face, body proportions, posture, and lighting.
- Integrate the clothing naturally with proper shape, alignment, fabric texture, and shadows.
- Combine multiple items into one coherent outfit (for example: dress + shoes + hat).
- Produce a natural, high-quality photographic result.
- Maintain a clean neutral background.
- Do NOT modify the user’s body or add any items not provided.
- Return only the final generated image, without any text.

This system simulates a virtual dressing room: Upload photo -> Upload clothes -> Generate final look.
`;

// Helper to strip data:image/xyz;base64, prefix
const cleanBase64 = (data: string) => {
  return data.replace(/^data:image\/\w+;base64,/, "");
};

const getMimeType = (data: string) => {
  const match = data.match(/^data:(image\/\w+);base64,/);
  return match ? match[1] : "image/jpeg";
};

export const generateTryOnLook = async (
  baseImage: string,
  clothingImages: string[]
): Promise<string> => {
  try {
    const parts: any[] = [];
    
    // Add Base Image
    parts.push({
      inlineData: {
        data: cleanBase64(baseImage),
        mimeType: getMimeType(baseImage),
      },
    });

    // Add Clothing Images
    clothingImages.forEach((img) => {
      parts.push({
        inlineData: {
          data: cleanBase64(img),
          mimeType: getMimeType(img),
        },
      });
    });

    // Add prompt
    parts.push({ text: "Generate the virtual try-on look based on these images." });

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-image",
      contents: {
        parts: parts,
      },
      config: {
        systemInstruction: TRY_ON_SYSTEM_PROMPT,
      },
    });

    // Extract image from response
    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    
    throw new Error("No image generated.");
  } catch (error) {
    console.error("Try-on generation failed:", error);
    throw error;
  }
};

export const editGeneratedImage = async (
  originalImage: string,
  prompt: string
): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-image",
      contents: {
        parts: [
          {
            inlineData: {
              data: cleanBase64(originalImage),
              mimeType: getMimeType(originalImage),
            },
          },
          { text: prompt },
        ],
      },
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }

    throw new Error("No edited image generated.");
  } catch (error) {
    console.error("Image editing failed:", error);
    throw error;
  }
};

export const sendChatMessage = async (
  history: ChatMessage[],
  newMessage: string
): Promise<string> => {
  try {
    const chat = ai.chats.create({
      model: "gemini-3-pro-preview",
      config: {
        thinkingConfig: {
          thinkingBudget: 32768, 
        },
      },
      history: history.map(h => ({
        role: h.role,
        parts: [{ text: h.text }],
      })),
    });

    const result = await chat.sendMessage({ message: newMessage });
    return result.text || "I couldn't generate a response.";
  } catch (error) {
    console.error("Chat failed:", error);
    return "Sorry, I encountered an error processing your request.";
  }
};
